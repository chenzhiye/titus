import java.util.ArrayList;
import java.util.List;

public class TestString {
    public static String removeConsecutiveSame(String str) {
        List<Character> charList = new ArrayList<>();
        for (char c : str.toCharArray()) {
            charList.add(c);
        }

        int index = 0;
        while (index < charList.size() - 2) {
            if (charList.get(index) == charList.get(index + 1) && charList.get(index) == charList.get(index + 2)) {
                charList.remove(index + 2);
                charList.remove(index + 1);
                charList.remove(index);
                StringBuilder resultPrint = new StringBuilder();
                for (char c : charList) {
                    resultPrint.append(c);
                }
                System.out.println(resultPrint.toString());
                if (index > 0) {
                    index--;
                }
            } else {
                index++;
            }
        }

        StringBuilder result = new StringBuilder();
        for (char c : charList) {
            result.append(c);
        }

        return result.toString();
    }

    public static void main(String[] args) {
        String str = "aaadabbbcccaa";
        removeConsecutiveSame(str);
    }
}