import java.util.ArrayList;
import java.util.List;

public class TestString2 {
    public static void replaceConsecutive(String input) {
        char[] charArray = input.toCharArray();
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < charArray.length; i++) {
            int count = 1;
            while (i + 1 < charArray.length && charArray[i] == charArray[i + 1]) {
                count++;
                i++;
            }

            if (count >= 3) {
                char replacedChar = (char) (charArray[i] - 1);
                if(!"`".equals(String.valueOf(replacedChar))) {
                    result.append(replacedChar);
                }
            } else {
                for (int j = 0; j < count; j++) {
                    result.append(charArray[i]);
                }
            }
        }

        if(!input.equals(result.toString())){
            System.out.println(result.toString());
            replaceConsecutive(result.toString());

        }
    }

    public static void main(String[] args) {
        String input = "abcccbad";
        replaceConsecutive(input);
    }
}