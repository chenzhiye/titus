import jdk.nashorn.internal.parser.JSONParser;

import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    static class SingleTons {
        private SingleTons() {

        }

        private final static SingleTons instance = new SingleTons();

        public static SingleTons getInstance() {
            return instance;
        }
    }

    public static void main(String[] args) {
        SingleTons instan = SingleTons.getInstance();
        int corePoolSize = 5;
        int maxPoolSize = 10;

        BlockingQueue<Runnable> queus = new LinkedBlockingQueue<>();
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(corePoolSize, maxPoolSize, 10, TimeUnit.SECONDS, queus);

        for (int i = 0; i < 10; i++) {
            int finalI = i;
            threadPoolExecutor.execute(() -> {
                System.out.println("thread" + finalI);
            });
        }

    }

    public class sumfrom100ThreadPool {

        int corePoolSize = 5;
        int maxPoolSize = 10;
    }
    //Executors executorP = Executors.newCachedThreadPool();
    //Executors executors = Executors.newFixedThreadPool();


}
